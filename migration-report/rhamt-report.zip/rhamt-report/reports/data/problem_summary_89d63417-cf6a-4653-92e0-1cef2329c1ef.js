MIGRATION_ISSUES_DETAILS["89d63417-cf6a-4653-92e0-1cef2329c1ef"] = [
{description: "<p>The use of Java RMI denotes a tight coupling that is better avoid in a cloud environment.<\/p><p>Java EE standard and loosely coupled protocols are recommended for backing services interactions.<\/p><p>Some examples are:<\/p>\n<ul>\n <li>message-based communication (JMS) for asynchronous use cases<\/li>\n <li>HTTP-based protocol or API (JAX-RS and JAX-WS) for synchronous use cases<\/li>\n<\/ul><p>In combination with load balancing, both options ensure scalability and high availability.<\/p>", ruleID: "java-rmi-00000", issueName: "Java Remote Method Invocation (RMI) service",
problemSummaryID: "89d63417-cf6a-4653-92e0-1cef2329c1ef", files: [
{l:"<a class='' href='ItemLookupHome_java.html?project=188560'>com.acme.anvil.service.ItemLookupHome<\/a>", oc:"1"},
{l:"<a class='' href='ProductCatalogHome_java.html?project=188560'>com.acme.anvil.service.ProductCatalogHome<\/a>", oc:"1"},
{l:"<a class='' href='ProductCatalog_java.html?project=188560'>com.acme.anvil.service.ProductCatalog<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://12factor.net/backing-services", t:"Twelve-factor app - Backing services"},
]},
];
onProblemSummaryLoaded("89d63417-cf6a-4653-92e0-1cef2329c1ef");