MIGRATION_ISSUES_DETAILS["26c04e19-b7f3-4396-a10b-1ddbfd6c9380"] = [
{description: "<p>The application embeds an Apache Log4J library.<\/p>", ruleID: "logging-usage-00010", issueName: "Embedded library - Apache Log4J",
problemSummaryID: "26c04e19-b7f3-4396-a10b-1ddbfd6c9380", files: [
{l:"simple-sample-app.ear/log4j-1.2.17.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("26c04e19-b7f3-4396-a10b-1ddbfd6c9380");