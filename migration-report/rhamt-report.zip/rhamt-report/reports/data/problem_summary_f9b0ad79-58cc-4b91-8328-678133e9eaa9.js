MIGRATION_ISSUES_DETAILS["f9b0ad79-58cc-4b91-8328-678133e9eaa9"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "f9b0ad79-58cc-4b91-8328-678133e9eaa9", files: [
{l:"<a class='' href='pom_xml.1.html?project=188560'>META-INF/maven/com.sun.mail/javax.mail/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.13.html?project=188560'>META-INF/maven/org.glassfish.main/javaee-api/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.17.html?project=188560'>META-INF/maven/org.jboss.windup.test.apps.weblogic/simple-sample-weblogic-services/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.21.html?project=188560'>META-INF/maven/org.jboss.ejb3/jboss-ejb3-ext-api/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.5.html?project=188560'>META-INF/maven/org.jboss.windup.test.apps.weblogic/simple-sample-weblogic-web/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.12.html?project=188560'>META-INF/maven/log4j/log4j/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.html?project=188560'>META-INF/maven/org.jboss.windup.test.apps.weblogic/simple-sample-weblogic-app/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.9.html?project=188560'>META-INF/maven/commons-lang/commons-lang/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("f9b0ad79-58cc-4b91-8328-678133e9eaa9");