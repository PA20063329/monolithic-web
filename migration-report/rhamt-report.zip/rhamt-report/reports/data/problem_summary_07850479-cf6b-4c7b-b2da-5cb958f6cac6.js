MIGRATION_ISSUES_DETAILS["07850479-cf6b-4c7b-b2da-5cb958f6cac6"] = [
{description: "<p>After migration, some of the JMX beans provided by the previous server may not be present anymore. Ensure that the <code>javax.management.ObjectName<\/code> does not need to change for JBoss EAP.<\/p>", ruleID: "environment-dependent-calls-04000", issueName: "JMX MBean object name (javax.management.ObjectName)",
problemSummaryID: "07850479-cf6b-4c7b-b2da-5cb958f6cac6", files: [
{l:"<a class='' href='AnvilWebLifecycleListener_java.html?project=188560'>com.acme.anvil.listener.AnvilWebLifecycleListener<\/a>", oc:"2"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("07850479-cf6b-4c7b-b2da-5cb958f6cac6");