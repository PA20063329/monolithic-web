MIGRATION_ISSUES_DETAILS["bfb6cc88-23f2-45a1-bd89-cbf8b7353870"] = [
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.i18n.logging.NonCatalogLogger<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "bfb6cc88-23f2-45a1-bd89-cbf8b7353870", files: [
{l:"<a class='' href='ProductCatalogBean_java.html?project=188560'>com.acme.anvil.service.ProductCatalogBean<\/a>", oc:"2"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("bfb6cc88-23f2-45a1-bd89-cbf8b7353870");