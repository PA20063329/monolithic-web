MIGRATION_ISSUES_DETAILS["c4d87a0e-94f1-4541-9705-01b8ebba5df6"] = [
{description: "<p>Java RMI should be avoided in cloud environments, as it tends to lead to tightly-coupled stateful applications with scalability problems. Consider replacing it with a solution using RESTful APIs or message queues.<\/p>", ruleID: "java-rmi-00001", issueName: "Java Remote Method Invocation (RMI) API",
problemSummaryID: "c4d87a0e-94f1-4541-9705-01b8ebba5df6", files: [
{l:"<a class='' href='ProductCatalogBean_java.html?project=188560'>com.acme.anvil.service.ProductCatalogBean<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("c4d87a0e-94f1-4541-9705-01b8ebba5df6");