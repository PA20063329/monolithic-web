MIGRATION_ISSUES_DETAILS["e11b600b-9680-4200-a619-ad66ae9e65a7"] = [
{description: "<p>Enterprise Java Bean XML Descriptor.<\/p>", ruleID: "DiscoverEjbConfigurationXmlRuleProvider_1", issueName: "EJB XML",
problemSummaryID: "e11b600b-9680-4200-a619-ad66ae9e65a7", files: [
{l:"<a class='' href='ejb_jar_xml.html?project=188560'>META-INF/ejb-jar.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("e11b600b-9680-4200-a619-ad66ae9e65a7");