MIGRATION_ISSUES_DETAILS["6abb7e3d-09fc-4dcc-99b9-28cb6dd129c7"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "6abb7e3d-09fc-4dcc-99b9-28cb6dd129c7", files: [
{l:"<a class='' href='web_xml.html?project=188560'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("6abb7e3d-09fc-4dcc-99b9-28cb6dd129c7");