MIGRATION_ISSUES_DETAILS["5b5c80b7-e65f-4286-829e-6f85d6b1ec3a"] = [
{description: "<p><code>QueueConnectionFactory<\/code> was used to obtain connection to JMS queues.<\/p><p>Replace the lookup string <code>QueueConnectionFactory<\/code> with <code>ConnectionFactory<\/code>.<\/p>", ruleID: "jboss-eap5-7-java-02000", issueName: "JMS legacy javax.jms.QueueConnectionFactory",
problemSummaryID: "5b5c80b7-e65f-4286-829e-6f85d6b1ec3a", files: [
{l:"<a class='' href='LogEventPublisher_java.html?project=188560'>com.acme.anvil.service.jms.LogEventPublisher<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.0/html/configuring_messaging/getting_started#connection_factories", t:"JBoss EAP 7 - Basic Messaging Configuration"},
{h:"https://docs.oracle.com/javaee/7/api/javax/jms/package-summary.html#package.description", t:"JavaEE 7 - JMS APIs"},
{h:"https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.0/html/configuring_messaging/configuring_messaging_connection_factories", t:"JBoss EAP 7 - Configuring Connection Factories"},
]},
];
onProblemSummaryLoaded("5b5c80b7-e65f-4286-829e-6f85d6b1ec3a");